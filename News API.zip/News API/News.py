from flask import Flask, render_template, request
from newsapi import NewsApiClient
import mysql.connector

connector = mysql.connector.connect(
    host='localhost',
    user='root',
    password='Medhasql5#',
    database='news'
)

cursor = connector.cursor()

app = Flask(__name__)

newsapi = NewsApiClient('70fdb9ba81ba40b6bda148e672898bd9')

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        search_query = request.form['search_query']
        search_results = newsapi.get_everything(q=search_query, language='en')
        news_articles = []
        for article in search_results['articles']:
            news_articles.append({
                'title': article['title'],
                'content': article['description'],
                'author': article['author'],
                'timestamp': article['publishedAt'],
                'image_url': article['urlToImage'],
                'article_url': article['url'],
            })
            query = "INSERT INTO news (title, content, author, article_url) VALUES(%s, %s, %s, %s)"
            value = (article['title'], article['description'], article['author'], article['url'])
            cursor.execute(query, value)

        connector.commit()
        return render_template('news.html', news=news_articles, search_query=search_query)

    else:
        top_headlines = newsapi.get_top_headlines(country='in', language='en')
        news_articles = []
        for article in top_headlines['articles']:
            news_articles.append({
                'title': article['title'],
                'content': article['description'],
                'author': article['author'],
                'timestamp': article['publishedAt'],
                'image_url': article['urlToImage'],
                'article_url': article['url'],
            })
            query = "INSERT INTO news(title, content, author, article_url) VALUES(%s, %s, %s, %s)"
            value = (article['title'], article['description'], article['author'], article['url'])
            cursor.execute(query, value)

        connector.commit()
        return render_template('news.html', news=news_articles)

@app.route('/ai_news', methods=['GET', 'POST'])
def ai():
    search_query = "AI and ML"
    search_results = newsapi.get_everything(q=search_query, language='en')
    news_articles = []
    for article in search_results['articles']:
        news_articles.append({
            'title': article['title'],
            'content': article['description'],
            'author': article['author'],
            'timestamp': article['publishedAt'],
            'image_url': article['urlToImage'],
            'article_url': article['url'],
        })
        query = "INSERT INTO news(title, content, author, article_url) VALUES(%s, %s, %s, %s)"
        value = (article['title'], article['description'], article['author'], article['url'])
        cursor.execute(query, value)

    connector.commit()
    return render_template('news.html', news=news_articles)


app.run(debug=True)
